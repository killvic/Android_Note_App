package com.example.note_app_hw.note_package

import android.support.v7.app.AppCompatActivity


data class NoteClass(
    var name: String = "",
    var text: String = "",
    var lastChange: Long = 0 // TO-DO implement calendar
    )