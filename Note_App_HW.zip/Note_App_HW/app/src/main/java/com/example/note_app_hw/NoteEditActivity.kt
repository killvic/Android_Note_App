package com.example.note_app_hw

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.example.note_app_hw.note_package.NoteClass

class NoteEditActivity : AppCompatActivity() {
    private lateinit var btExitNote: Button
    private lateinit var btSaveNote: Button
    private lateinit var etNoteName: EditText
    private lateinit var etNoteText: EditText
    private var notes = mutableListOf<NoteClass>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note_edit)
        var notes = mutableListOf<NoteClass>()

        // views initialization
        btExitNote = findViewById(R.id.btBackToNotesList)
        btSaveNote = findViewById(R.id.btSaveNote)
        etNoteName = findViewById(R.id.etNoteName)
        etNoteText = findViewById(R.id.etNoteText)


        btExitNote.setOnClickListener{
            backToNotesList()
        }

        btSaveNote.setOnClickListener{
            saveNote()
        }
    }

    private fun backToNotesList(){
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    private fun saveNote(){
        addNote()
        // ? display a success message
    }

    private fun addNote(){
        var newNote = NoteClass(
            etNoteName.text.toString(),
            etNoteName.text.toString(),
            System.currentTimeMillis())
        notes.add(newNote)
    }
}